export default function Profile() {
  return <h1>Profile</h1>;
}
