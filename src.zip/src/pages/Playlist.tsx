export default function Playlist() {
  return <h1>Playlist</h1>;
}
