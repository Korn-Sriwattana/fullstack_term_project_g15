import styles from "../assets/styles/Home.module.css";

export default function Home() {
  return (
    <div className={styles.homeContainer}>
      <h1>Home</h1>
    </div>
  );
}
