export default function LikedSongs() {
  return <h1>Liked Songs</h1>;
}
